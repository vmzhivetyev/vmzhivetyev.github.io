#!/usr/bin/env bash

./auto.out
