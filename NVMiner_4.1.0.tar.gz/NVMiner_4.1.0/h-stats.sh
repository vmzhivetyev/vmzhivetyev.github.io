#!/usr/bin/env bash

MINER_API_PORT=36207
stats_raw=`curl --silent --connect-timeout 2  --max-time 5 localhost:${MINER_API_PORT}`

if [[ $? -ne 0 || -z $stats_raw ]]; then
	echo -e "${YELLOW}Failed to read miner stats from localhost:${MINER_API_PORT}${NOCOLOR}"
else
	# bus_numbers=[]
	# bus_numbers=`echo "$stats_raw" | jq '.devices[].pciid' | jq -cs '.'`
	bus_numbers="[ 0 ]"

	stats=$(jq --argjson bus_numbers "$bus_numbers" \
	           --arg gpuerr "`echo ${gpuerr[*]} | tr ' ' ';'`" \
	'{ hs: [.devices[].hashrate], hs_units: "mhs", temp: [.devices[].temperature], fan: [.devices[].fan], uptime: .uptime, $bus_numbers, algo: "autolykos2", ver: "4.1.0" }' <<< "$stats_raw")

	# total hashrate in khs
	khs=$(jq ".total*1000" <<< "$stats_raw")
fi

[[ -z $khs ]] && khs=0
[[ -z $stats ]] && stats="null"
